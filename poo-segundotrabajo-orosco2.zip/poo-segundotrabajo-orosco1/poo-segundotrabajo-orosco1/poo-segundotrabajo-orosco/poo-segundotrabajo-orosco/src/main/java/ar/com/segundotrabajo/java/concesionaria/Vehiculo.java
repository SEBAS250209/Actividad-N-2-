package ar.com.segundotrabajo.java.concesionaria;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;


@Getter
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)

public abstract class Vehiculo implements Comparable<Vehiculo>{
    @EqualsAndHashCode.Include
    private String marca;
    @EqualsAndHashCode.Include
    private String modelo;
    @EqualsAndHashCode.Include
    private double precio;


@Override

public int compareTo(Vehiculo vehiculopara) {
    String thiSvehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecio();
    String Vehiculopara = vehiculopara.getMarca() + "," + vehiculopara.getModelo() + "," + vehiculopara.getPrecio();
    return thiSvehiculo.compareTo(Vehiculopara);
        
}




}
