package ar.com.segundotrabajo.java.concesionaria;

public class Moto extends Vehiculo{
    private String cilindrada;

    public Moto(String marca, String modelo, String cilindrada, double precio) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %s // Precio: $%,.2f",
                getMarca(), getModelo(), cilindrada, getPrecio());
    }
    

}
