package ar.com.segundotrabajo.java.Test;

import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import ar.com.segundotrabajo.java.concesionaria.Vehiculo;
import ar.com.segundotrabajo.java.concesionaria.VehiculoDisponible;

public class TestConcesionaria {
public static void main(String[] args) {

    DecimalFormat formatoPrecio = new DecimalFormat(" $#,###.00");

    List<Vehiculo> vehiculos = VehiculoDisponible.obtenerVehiculos();
    //mostramos los vehiculos
    vehiculos.forEach(System.out::println);
    
    System.out.println("=============================");
    //Vehiculo más caro
    double preciomaximo = 
                        vehiculos
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();   
    
                        vehiculos
                                .stream()
                                .filter(v->v.getPrecio() == preciomaximo)
                                .forEach(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    //Vehículo más barato
    double preciominimo = 
                        vehiculos
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();   
    
                        vehiculos
                                .stream()
                                .filter(v->v.getPrecio() == preciominimo)
                                .forEach(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));

    //Vehículo que contiene en el modelo la letra ‘Y’: Yamaha YBR $80.500,50
    vehiculos
                .stream()
                .filter(v->v.getMarca().toLowerCase().contains("y"))
                .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra ´Y´:"+ v.getMarca() + " "+ v.getModelo() + " "+ formatoPrecio.format(v.getPrecio())));

    System.out.println("=============================");

    //Vehículos ordenados por precio de mayor a menor:
    System.out.println("Vehículos ordenados por precio de mayor a menor:");
    vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio)
                .reversed()
                .thenComparing(Vehiculo::getPrecio))
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    
    System.out.println("=============================");

    //Vehículos ordenados por orden natural (marca, modelo, precio):
    System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
    Set<Vehiculo> setDeVehiculo;
    setDeVehiculo = new TreeSet<>();
    setDeVehiculo.addAll(vehiculos);
    setDeVehiculo.forEach(System.out::println);

    
    }
    


}


