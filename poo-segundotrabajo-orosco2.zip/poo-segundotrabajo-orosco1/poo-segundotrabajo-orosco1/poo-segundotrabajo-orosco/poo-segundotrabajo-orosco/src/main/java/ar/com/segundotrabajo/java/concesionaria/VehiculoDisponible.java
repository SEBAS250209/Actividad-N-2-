package ar.com.segundotrabajo.java.concesionaria;

import java.util.ArrayList;
import java.util.List;

public class VehiculoDisponible {
    
    // se crea el metodo obtenerVehiculos() que crea y retorna una lista.
     public static List<Vehiculo> obtenerVehiculos() {
        List<Vehiculo> vehiculos = new ArrayList<>();
        vehiculos.add(new Auto("Peugeot", "206", 4, 200000));
        vehiculos.add(new Moto("Honda", "Titan", "125cc", 60000));
        vehiculos.add(new Auto("Peugeot", "208", 5, 250000));
        vehiculos.add(new Moto("Yamaha", "YBR", "160cc", 80500.50));
        return vehiculos;
    }

        
}



