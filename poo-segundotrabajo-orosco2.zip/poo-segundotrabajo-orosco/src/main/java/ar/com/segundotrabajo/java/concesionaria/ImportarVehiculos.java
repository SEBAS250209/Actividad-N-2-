package ar.com.segundotrabajo.java.concesionaria;

import java.util.ArrayList;
import java.util.List;

public class ImportarVehiculos {
    
    /**
     * Crea el metodo ObtenerVehiculo(), el cual crea una lista donde solo se puede 
     * cargar objetos del tipo Vehiculo y luego la retorna.
     * @return Lista de objetos Vehiculo (Auto y Moto)
     */
     public static List<Vehiculo> obtenerVehiculos() {
        List<Vehiculo> vehiculos = new ArrayList<>();
        vehiculos.add(new Auto("Peugeot", "206", 4, 200000));
        vehiculos.add(new Moto("Honda", "Titan", "125cc", 60000));
        vehiculos.add(new Auto("Peugeot", "208", 5, 250000));
        vehiculos.add(new Moto("Yamaha", "YBR", "160cc", 80500.50));
        return vehiculos;
    }

        
}



