package ar.com.segundotrabajo.java.concesionaria;

import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.List;

public class MetodosTest {

    /**
     * Recibe como parametro una lista con la cual va a trabajar.
     * Verifica que la lista no este vacia, si no 
     * esta vacia muestra el vehículo más caro.
     * @param vehiculos
     */
    public static void mostrarVehiculoMasCaro(List<Vehiculo> vehiculos) {
         
        if (vehiculos == null || vehiculos.isEmpty()) {
                System.out.println("No hay vehículos para analizar.");
                return;
        }
    
        double precioMaximo = vehiculos
            .stream()
            .max(Comparator.comparingDouble(Vehiculo::getPrecio))
            .get()
            .getPrecio();

        vehiculos
            .stream()
            .filter(v -> v.getPrecio() == precioMaximo)
            .forEach(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));

    }
    
    /**
     * Verifica que la lista no este vacia, si no 
     * esta vacia muestra el vehículo más barato.
     * @param vehiculos
     */
    public static void mostrarVehiculoMasBarato(List<Vehiculo> vehiculos){  
        if (vehiculos == null || vehiculos.isEmpty()) {
            System.out.println("No hay vehículos para analizar.");
            return;
        }
        double precioMinimo = 
                            vehiculos
                                    .stream()
                                    .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                    .get()
                                    .getPrecio();   
    
        vehiculos
            .stream()
            .filter(v->v.getPrecio() == precioMinimo)
            .forEach(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }
    
    /**
     * Recibe como parametro una lista con la cual va a trabajar, y una letra la que va a comoparar
     * Verifica  que la lista no este vacia, luego hace la comparación con la letra ingresada.
     * @param vehiculos
     * @param letra
     */
    public static void mostrarVehiculosConLetraEnModelo(List<Vehiculo> vehiculos, String letra) {
        DecimalFormat formatoPrecio = new DecimalFormat(" $#,###.00");

        String letraBuscada = letra.toLowerCase();

        if (vehiculos == null || vehiculos.isEmpty()) {
                System.out.println("No hay vehículos para analizar.");
                return;
        }
        
        vehiculos
            .stream()
            .filter(v->v.getMarca().toLowerCase().contains(letraBuscada))
            .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra ´Y´:"+ v.getMarca() + " "+ v.getModelo() + " "+ formatoPrecio.format(v.getPrecio())));
    
    }

    /**
     * Muestra los vehículos con el precio de mayor a menor
     * @param vehiculos
     */
    public static void mostrasVehiculosDeMayorMenor(List<Vehiculo> vehiculos){
        
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio)
                .reversed()
                .thenComparing(Vehiculo::getPrecio))
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
        
    }

}