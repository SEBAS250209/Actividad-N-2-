package ar.com.segundotrabajo.java.concesionaria;
public class Auto extends Vehiculo{
    private int puertas;

    /**
     * Constructor que inicializa un Auto, el cual hereda de Vehiculo.
     * @param marca
     * @param modelo
     * @param puertas
     * @param precio
     */
    public Auto(String marca, String modelo,int puertas, double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
        
    }

     @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Puertas: %d // Precio: $%,.2f",
                getMarca(), getModelo(), puertas, getPrecio());
    }

}
