package ar.com.segundotrabajo.java.Test;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import ar.com.segundotrabajo.java.concesionaria.MetodosTest;
import ar.com.segundotrabajo.java.concesionaria.Vehiculo;
import ar.com.segundotrabajo.java.concesionaria.ImportarVehiculos;

public class TestConcesionaria {
public static void main(String[] args) {

   

    List<Vehiculo> vehiculos = ImportarVehiculos.obtenerVehiculos();
    //mostramos los vehiculos
    vehiculos.forEach(System.out::println);

    System.out.println("");
    System.out.println("=============================");
    System.out.println("");

    //Vehiculo más caro
    
    List<Vehiculo> vehiculosCaro= ImportarVehiculos.obtenerVehiculos(); // o una vacía
    MetodosTest.mostrarVehiculoMasCaro(vehiculosCaro); // el método se encarga de todo

    //Vehículo más barato
    List<Vehiculo> vehiculoBarato= ImportarVehiculos.obtenerVehiculos();
    MetodosTest.mostrarVehiculoMasBarato(vehiculoBarato);

    //Vehículo que contiene en el modelo la letra ‘Y’: Yamaha YBR $80.500,50
    List<Vehiculo> VehiculoConLetraModelo = ImportarVehiculos.obtenerVehiculos();
    MetodosTest.mostrarVehiculosConLetraEnModelo(VehiculoConLetraModelo, "y");

    System.out.println("");
    System.out.println("=============================");
    System.out.println("");

    //Vehículos ordenados por precio de mayor a menor:
    System.out.println("Vehículos ordenados por precio de mayor a menor:");
    List<Vehiculo> VehiculoDeMayorMenor = ImportarVehiculos.obtenerVehiculos();
    MetodosTest.mostrasVehiculosDeMayorMenor(VehiculoDeMayorMenor);
    
    System.out.println("");
    System.out.println("=============================");
    System.out.println("");
    
    //Vehículos ordenados por orden natural (marca, modelo, precio):
    System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
    Set<Vehiculo> setDeVehiculo;
    setDeVehiculo = new TreeSet<>();
    setDeVehiculo.addAll(vehiculos);
    setDeVehiculo.forEach(System.out::println);

    
    }
    


}


